# This is my better script
# Done using different approaches
# This is definitely my better script
# This script is not good
